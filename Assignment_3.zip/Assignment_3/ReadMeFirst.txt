1. The three videos used in this assignment are placed at src\resources

2. These three videos are accessed inside React JS code using http-server url i.e. http://127.0.0.1:8080

3. Before starting the application using npm start please go to the src\resources using command prompt and run http-server command assuming http-server is already installed.

4. After running http-server successfully please execute the npm start command from package.json directory location.

5. Please use Google Chrome browser to test the application.